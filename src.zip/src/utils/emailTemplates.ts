import { Order } from '../types';

export function formatPKR(val: number): string {
  return 'Rs. ' + val.toLocaleString('en-PK');
}

export function generateCustomerEmailHtml(order: Order): { subject: string; html: string } {
  const subject = `Order Confirmation - #${order.id}`;
  const itemsRows = order.items
    .map(
      (item) => `
    <tr style="border-bottom: 1px solid #e7e5e4;">
      <td style="padding: 12px 8px; font-size: 14px; color: #1c1917; font-weight: 500;">
        ${item.product.title}
        <div style="font-size: 12px; color: #78716c;">SKU: ${item.product.sku} · Qty: ${item.quantity}</div>
      </td>
      <td style="padding: 12px 8px; font-size: 14px; text-align: right; color: #1c1917; font-family: monospace;">
        ${formatPKR(item.product.pricePKR * item.quantity)}
      </td>
    </tr>
  `
    )
    .join('');

  const paymentTitle =
    order.payment.method === 'easypaisa'
      ? 'EasyPaisa Wallet'
      : order.payment.method === 'jazzcash'
      ? 'JazzCash Wallet'
      : 'Direct Bank Transfer (IBFT)';

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${subject}</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f5f5f4; margin: 0; padding: 24px; color: #292524;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border: 1px solid #e7e5e4; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
          <!-- Header -->
          <tr>
            <td style="background-color: #1c1917; padding: 28px 32px; text-align: left;">
              <h1 style="color: #f5f5f4; font-size: 20px; margin: 0; letter-spacing: -0.02em; font-family: Georgia, serif;">KHAAS PAKISTAN</h1>
              <p style="color: #a8a29e; font-size: 13px; margin: 6px 0 0 0;">Handcrafted Heritage & Luxury Goods</p>
            </td>
          </tr>
          
          <!-- Body Content -->
          <tr>
            <td style="padding: 32px;">
              <h2 style="font-size: 18px; color: #1c1917; margin: 0 0 12px 0;">Thank You for Your Order, ${order.customer.fullName}!</h2>
              <p style="font-size: 14px; line-height: 1.6; color: #57534e; margin: 0 0 24px 0;">
                We have received your order <strong>#${order.id}</strong>. Our team is currently reviewing your payment details. You will receive courier dispatch confirmation once your parcel is on its way.
              </p>

              <!-- Order Summary Box -->
              <div style="background-color: #fafaf9; border: 1px solid #e7e5e4; border-radius: 6px; padding: 18px; margin-bottom: 24px;">
                <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px;">
                  <tr>
                    <td style="color: #78716c; padding-bottom: 6px;">Order Number:</td>
                    <td style="text-align: right; font-weight: 600; color: #1c1917; padding-bottom: 6px;">#${order.id}</td>
                  </tr>
                  <tr>
                    <td style="color: #78716c; padding-bottom: 6px;">Payment Method:</td>
                    <td style="text-align: right; font-weight: 600; color: #1c1917; padding-bottom: 6px;">${paymentTitle}</td>
                  </tr>
                  <tr>
                    <td style="color: #78716c; padding-bottom: 6px;">Transaction ID / Ref:</td>
                    <td style="text-align: right; font-family: monospace; color: #0284c7; padding-bottom: 6px;">${order.payment.transactionId || 'Awaiting Input'}</td>
                  </tr>
                  <tr>
                    <td style="color: #78716c;">Estimated Delivery:</td>
                    <td style="text-align: right; font-weight: 600; color: #15803d;">3-5 Business Days (Nationwide)</td>
                  </tr>
                </table>
              </div>

              <!-- Itemized Bill -->
              <h3 style="font-size: 14px; text-transform: uppercase; letter-spacing: 0.05em; color: #78716c; margin: 0 0 12px 0; border-bottom: 2px solid #f5f5f4; padding-bottom: 6px;">Itemized Bill</h3>
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px;">
                ${itemsRows}
                <tr>
                  <td style="padding: 8px 8px 4px 8px; font-size: 14px; color: #78716c;">Subtotal</td>
                  <td style="padding: 8px 8px 4px 8px; font-size: 14px; text-align: right; font-family: monospace;">${formatPKR(order.subtotalPKR)}</td>
                </tr>
                <tr>
                  <td style="padding: 4px 8px; font-size: 14px; color: #78716c;">Courier Shipping (Standard)</td>
                  <td style="padding: 4px 8px; font-size: 14px; text-align: right; font-family: monospace; color: ${order.shippingFeePKR === 0 ? '#15803d' : '#1c1917'};">
                    ${order.shippingFeePKR === 0 ? 'FREE (Orders over Rs. 5,000)' : formatPKR(order.shippingFeePKR)}
                  </td>
                </tr>
                <tr style="border-top: 2px solid #1c1917;">
                  <td style="padding: 12px 8px; font-size: 16px; font-weight: 700; color: #1c1917;">Total Amount</td>
                  <td style="padding: 12px 8px; font-size: 16px; font-weight: 700; text-align: right; font-family: monospace; color: #1c1917;">${formatPKR(order.totalPKR)}</td>
                </tr>
              </table>

              <!-- Shipping Address -->
              <div style="background-color: #fafaf9; border-left: 3px solid #78716c; padding: 14px 18px; margin-bottom: 24px;">
                <div style="font-size: 12px; text-transform: uppercase; font-weight: 600; color: #78716c; margin-bottom: 4px;">Delivery Destination</div>
                <div style="font-size: 14px; font-weight: 600; color: #1c1917;">${order.customer.fullName} · ${order.customer.phone}</div>
                <div style="font-size: 13px; color: #57534e; margin-top: 2px;">
                  ${order.customer.streetAddress}, ${order.customer.city} (${order.customer.postalCode})
                </div>
              </div>

              <!-- WhatsApp & Helpdesk Support -->
              <div style="text-align: center; padding-top: 12px; border-top: 1px solid #e7e5e4;">
                <p style="font-size: 13px; color: #78716c; margin: 0 0 12px 0;">Need immediate assistance or want to send your payment screenshot?</p>
                <a href="https://wa.me/923458821900?text=Salam,%20I%20have%20an%20inquiry%20regarding%20Order%20${order.id}" 
                   style="display: inline-block; background-color: #15803d; color: #ffffff; text-decoration: none; padding: 10px 20px; font-size: 13px; font-weight: 600; border-radius: 6px;">
                  💬 Chat on WhatsApp Support (+92 345 8821900)
                </a>
              </div>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #fafaf9; border-top: 1px solid #e7e5e4; padding: 20px 32px; font-size: 12px; color: #a8a29e; text-align: center;">
              Khaas Pakistan · Gulberg III, Lahore, Pakistan · UAN: +92 (42) 111-00-5422
            </td>
          </tr>
        </table>
      </body>
    </html>
  `;

  return { subject, html };
}

export function generateAdminEmailHtml(order: Order): { subject: string; html: string } {
  const subject = `[ACTION REQUIRED] New Order #${order.id}`;

  const paymentStatusBadge =
    order.stage === 'PAYMENT_PENDING'
      ? 'Awaiting Payment Verification'
      : order.stage === 'PROCESSING'
      ? 'Payment Confirmed / Packing'
      : order.stage === 'SHIPPED'
      ? 'Dispatched'
      : 'Delivered';

  const itemsList = order.items
    .map(
      (item) => `
    <li><strong>${item.quantity}x</strong> ${item.product.title} (SKU: ${item.product.sku}) - ${formatPKR(item.product.pricePKR * item.quantity)}</li>
  `
    )
    .join('');

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <title>${subject}</title>
      </head>
      <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f1f5f9; margin: 0; padding: 24px; color: #0f172a;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);">
          <!-- Admin Alert Banner -->
          <tr>
            <td style="background-color: #b91c1c; padding: 18px 24px; color: #ffffff;">
              <table width="100%">
                <tr>
                  <td>
                    <span style="background-color: rgba(255,255,255,0.2); padding: 3px 8px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; border-radius: 4px;">Store Admin Alert</span>
                    <h2 style="margin: 6px 0 0 0; font-size: 18px; color: #ffffff;">New Order Placed: #${order.id}</h2>
                  </td>
                  <td style="text-align: right; font-size: 14px; font-weight: 700; font-family: monospace;">
                    ${formatPKR(order.totalPKR)}
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 24px;">
              <!-- Status & Payment info -->
              <div style="background-color: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; padding: 14px; margin-bottom: 20px;">
                <div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #92400e;">Payment Verification Required</div>
                <div style="font-size: 14px; color: #78350f; margin-top: 4px;">
                  Gateway: <strong>${order.payment.method.toUpperCase()}</strong> · Status: <strong>${paymentStatusBadge}</strong>
                </div>
                <div style="font-size: 13px; font-family: monospace; color: #1e293b; margin-top: 4px;">
                  TRX ID: ${order.payment.transactionId || 'None Provided'}
                </div>
              </div>

              <!-- Customer Details -->
              <h3 style="font-size: 13px; text-transform: uppercase; color: #64748b; letter-spacing: 0.05em; margin: 0 0 10px 0;">Customer Information</h3>
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px; margin-bottom: 20px;">
                <tr>
                  <td style="color: #64748b; padding: 4px 0; width: 35%;">Full Name:</td>
                  <td style="font-weight: 600; color: #0f172a; padding: 4px 0;">${order.customer.fullName}</td>
                </tr>
                <tr>
                  <td style="color: #64748b; padding: 4px 0;">Validated Phone:</td>
                  <td style="font-weight: 600; color: #0f172a; padding: 4px 0;">${order.customer.phone}</td>
                </tr>
                <tr>
                  <td style="color: #64748b; padding: 4px 0;">Email:</td>
                  <td style="color: #2563eb; padding: 4px 0;">${order.customer.email}</td>
                </tr>
                <tr>
                  <td style="color: #64748b; padding: 4px 0;">Delivery Address:</td>
                  <td style="color: #334155; padding: 4px 0;">${order.customer.streetAddress}, ${order.customer.city} (${order.customer.postalCode})</td>
                </tr>
                ${order.customer.orderNotes ? `
                <tr>
                  <td style="color: #64748b; padding: 4px 0;">Order Notes:</td>
                  <td style="color: #b45309; padding: 4px 0; font-style: italic;">"${order.customer.orderNotes}"</td>
                </tr>` : ''}
              </table>

              <!-- Order Items -->
              <h3 style="font-size: 13px; text-transform: uppercase; color: #64748b; letter-spacing: 0.05em; margin: 0 0 10px 0;">Ordered Line Items</h3>
              <ul style="font-size: 13px; color: #334155; margin: 0 0 24px 0; padding-left: 20px; line-height: 1.6;">
                ${itemsList}
              </ul>

              <!-- Actions -->
              <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 18px; text-align: center;">
                <p style="font-size: 13px; color: #475569; margin: 0 0 14px 0;">Quick Fulfillment Actions:</p>
                <div style="display: flex; gap: 10px; justify-content: center;">
                  <span style="display: inline-block; background-color: #0f172a; color: #ffffff; padding: 10px 18px; font-size: 13px; font-weight: 600; border-radius: 6px;">
                    ✓ Verify Payment in Admin Panel
                  </span>
                  <span style="display: inline-block; background-color: #e2e8f0; color: #1e293b; padding: 10px 18px; font-size: 13px; font-weight: 600; border-radius: 6px; margin-left: 8px;">
                    🖨️ Generate Packing Slip
                  </span>
                </div>
              </div>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f8fafc; border-top: 1px solid #e2e8f0; padding: 16px 24px; font-size: 11px; color: #94a3b8; text-align: center;">
              Automated Store Dispatcher · Dedicated High-Deliverability SMTP Relay (SendGrid/Postmark)
            </td>
          </tr>
        </table>
      </body>
    </html>
  `;

  return { subject, html };
}
