import { Product, Order } from '../types';

export const PAKISTAN_CITIES = [
  'Lahore',
  'Karachi',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Gujranwala',
  'Hyderabad',
  'Abbottabad',
  'Bahawalpur',
  'Sargodha',
  'Sukkur',
  'Mardan'
];

export const PAYMENT_GATEWAY_CONFIG = {
  easypaisa: {
    title: 'EasyPaisa Mobile Wallet',
    accountNumber: '0345-8821900',
    accountTitle: 'KHAAS ARTISAN PVT LTD',
    instructions: 'Send money via EasyPaisa App > EasyPaisa Transfer to Mobile Account. Enter Mobile No: 0345-8821900. After sending, enter the 11-digit TRX ID below or upload confirmation screenshot.',
    supportPhone: '+92 345 8821900',
    feeNote: 'No transaction surcharge'
  },
  jazzcash: {
    title: 'JazzCash Wallet & Till',
    merchantTillId: '00291822',
    accountNumber: '0300-5544321',
    accountTitle: 'KHAAS RETAIL PAKISTAN',
    instructions: 'Send via JazzCash App or Dial *786# > Send Money to Mobile Account / Till. Enter Account: 0300-5544321 or Till ID: 00291822. Provide the 10-12 digit TID from the SMS receipt.',
    supportPhone: '+92 300 5544321',
    feeNote: 'Instant verification via Txn ID'
  },
  ibft: {
    title: 'Direct Bank Transfer (IBFT)',
    bankName: 'Meezan Bank Limited',
    accountTitle: 'Khaas Lifestyle Pvt Ltd',
    accountNumber: '0100-0103492811',
    iban: 'PK36MEZN0001000103492811',
    branch: 'Main Boulevard, Gulberg III, Lahore',
    swiftCode: 'MEZNPKKA',
    instructions: 'Initiate an Interbank Fund Transfer (IBFT) from any Pakistani banking app (HBL, Meezan, Alfalah, UBL, SCB). Enter IBAN above. Upload your payment receipt or enter the Transfer Reference Code.',
    feeNote: 'Manual admin verification within 1-2 hours'
  }
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prd-05',
    title: "Ru's Glow Turmeric & Papaya Brightening Soap",
    subtitle: 'Turmeric, Papaya, Kojic Acid & Goat Milk',
    pricePKR: 650,
    originalPricePKR: 800,
    image: '/src/assets/images/product_rus_glow_turmeric_soap.jpg',
    category: 'Skincare',
    origin: "Ru's Organics, Lahore, Punjab",
    inStock: true,
    stockCount: 30,
    description: "Handmade organic soap bar by Ru's Glow, enriched with turmeric, papaya, kojic acid and goat milk. Gently cleanses while helping brighten dull skin and even out skin tone.",
    specs: ['Key ingredients: Turmeric, Papaya, Kojic Acid, Goat Milk', 'Handmade organic soap bar', 'Suitable for face and body', 'Brand: Ru\'s Glow by Ru\'s Organics'],
    sku: 'KH-RUG-005'
  },
  {
    id: 'prd-06',
    title: "Ru's Glow Neem & Moringa Anti-Acne Soap",
    subtitle: 'Moringa, Neem, Aloe Vera, Kojic Acid & Goat Milk',
    pricePKR: 650,
    originalPricePKR: 800,
    image: '/src/assets/images/product_rus_glow_neem_soap.jpg',
    category: 'Skincare',
    origin: "Ru's Organics, Lahore, Punjab",
    inStock: true,
    stockCount: 30,
    description: "Handmade anti-acne and skin brightening soap by Ru's Glow, made with moringa, neem, aloe vera, kojic acid and goat milk. Helps clear breakouts while soothing and brightening skin.",
    specs: ['Key ingredients: Moringa, Neem, Aloe Vera, Kojic Acid, Goat Milk', 'Anti-acne and skin brightening', 'Handmade organic soap bar', 'Brand: Ru\'s Glow by Ru\'s Organics'],
    sku: 'KH-RUG-006'
  }
];

export const INITIAL_ORDERS: Order[] = [];
